package com.analizador.backEnd.parser.model.sentencia;

import com.analizador.backEnd.lexer.almacenamieto.ListaEnlazada;

public class SentenciaNoLocal {

    public boolean scanNoLocal(ListaEnlazada tmpListTokens){

        return false;
    }

}
