package com.analizador.backEnd.lexer.dictionary;

public enum BloqueCodigo {

    NEWLINE,
    IDENTACION,    
    DEDENT,
    OEF;
    
}
