package com.analizador.backEnd.parser.model.sentencia;


import com.analizador.backEnd.lexer.almacenamieto.ListaEnlazada;

public class SentenciaGlobal {

    public boolean scanGlobal (ListaEnlazada tmpListTokens){

        return false;

    }


    
}
