package com.analizador;

import com.analizador.frontEnd.VentanPrincipal;

/**
 * Hello world!
 *
 */
public class Main 
{
    public static void main( String[] args )
    {
        System.out.println(" Holis XD");
        new VentanPrincipal();
        
    }
}
 