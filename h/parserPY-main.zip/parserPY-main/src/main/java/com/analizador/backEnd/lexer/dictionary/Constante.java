package com.analizador.backEnd.lexer.dictionary;

public enum Constante {

    INT,//("int"),
    DOUBLE,//("double"),
    STRING,//("String"),
    CHAR,//("char"),
    ID,//("id"),
    ErrorLexico,
    EOF;//("EOF");
        
}
