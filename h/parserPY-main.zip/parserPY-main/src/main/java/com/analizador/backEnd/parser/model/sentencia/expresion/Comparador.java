package com.analizador.backEnd.parser.model.sentencia.expresion;

public class Comparador {
    
}
