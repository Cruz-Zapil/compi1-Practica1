package com.analizador.backEnd.parser.model.sentencia;


import com.analizador.backEnd.lexer.almacenamieto.ListaEnlazada;

public class SenetenciaYield {

    public boolean scanSentenciaYield(ListaEnlazada tmpListTokens) {

        return false;
    }

}
