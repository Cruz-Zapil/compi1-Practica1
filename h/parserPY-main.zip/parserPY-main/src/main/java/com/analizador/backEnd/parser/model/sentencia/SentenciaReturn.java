package com.analizador.backEnd.parser.model.sentencia;

import com.analizador.backEnd.lexer.almacenamieto.ListaEnlazada;

public class SentenciaReturn {
    

    public boolean scanReturn(ListaEnlazada tmpListTokens){

        

        return false;
    }
    
}
