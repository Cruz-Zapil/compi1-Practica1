package com.analizador.frontEnd.paneles.panelReporte;

public class ReporteAuxi {
    
}
