package com.analizador.backEnd.parser.model.sentencia;

import com.analizador.backEnd.lexer.almacenamieto.ListaEnlazada;

public class SentenciaWith {
    


    public boolean scanSentenciaWhit(ListaEnlazada tmpListTokens){


        return false;
    }


}
