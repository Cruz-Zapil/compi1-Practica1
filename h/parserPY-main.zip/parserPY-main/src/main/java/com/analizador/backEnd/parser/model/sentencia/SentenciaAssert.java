package com.analizador.backEnd.parser.model.sentencia;

import com.analizador.backEnd.lexer.almacenamieto.ListaEnlazada;

public class SentenciaAssert {

    public boolean scanAssert(ListaEnlazada tmpListTokens){


        

        return false;
    }
    
    
}
